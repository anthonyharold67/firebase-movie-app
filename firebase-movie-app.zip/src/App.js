import React from "react";

const App = () => {
  return (
    <div>
      <h2>Movie App</h2>
    </div>
  );
};

export default App;
